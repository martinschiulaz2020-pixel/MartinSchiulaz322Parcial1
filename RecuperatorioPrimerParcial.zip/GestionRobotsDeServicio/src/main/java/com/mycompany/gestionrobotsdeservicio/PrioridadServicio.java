
package com.mycompany.gestionrobotsdeservicio;


public enum PrioridadServicio {
    BAJA,
    MEDIA,
    ALTA;
}
