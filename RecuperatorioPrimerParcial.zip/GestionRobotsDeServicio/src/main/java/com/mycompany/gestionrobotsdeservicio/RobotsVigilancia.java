
package com.mycompany.gestionrobotsdeservicio;


public class RobotsVigilancia extends Robots implements GenerarDiagnostico{
    
    
    
    public RobotsVigilancia(String numeroSerie, String fabricante, 
            PrioridadServicio prioridad, int nivelBateria) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
    }

    @Override
    int calcularConsumoEnergia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String Diagnostico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
