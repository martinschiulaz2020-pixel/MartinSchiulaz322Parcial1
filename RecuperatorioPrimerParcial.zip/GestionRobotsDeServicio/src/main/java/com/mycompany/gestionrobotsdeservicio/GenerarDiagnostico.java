
package com.mycompany.gestionrobotsdeservicio;


public interface GenerarDiagnostico {
    
    
    String diagnostico();
}
