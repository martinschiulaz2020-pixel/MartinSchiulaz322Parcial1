
package com.mycompany.gestionrobotsdeservicio;


public class RobotDuplicadoException extends Exception{
    
    private final static String MENSAJE = "Robot duplicado";
    
    public RobotDuplicadoException(String MENSAJE) {
    }

    public RobotDuplicadoException(){
        super();
    }
    
    
}
