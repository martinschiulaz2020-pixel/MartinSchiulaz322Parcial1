
package com.mycompany.gestionrobotsdeservicio;


public class RobotsLimpieza extends Robots implements EjecutarServicio {
    private int superficieTrabajo;

    public RobotsLimpieza(String numeroSerie, String fabricante, 
            PrioridadServicio prioridad, int nivelBateria, int superficieTrabajo) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        this.superficieTrabajo = superficieTrabajo;
    }

    @Override
    int calcularConsumoEnergia() {
        return (superficieTrabajo * superficieTrabajo) / 10 + 5;
    }

    @Override
    public String servicio() {
        if (getNivelBateria() > calcularConsumoEnergia()){
            System.out.println("Se ejecuto el servicio");
        }
        throw new IllegalStateException();
    }

    @Override
    public String toString() {
        return "RobotsLimpieza{" + "superficieTrabajo=" + superficieTrabajo + "numeroSerie=" 
                + getNumeroSerie() + ", fabricante=" + getFabricante()
                + ", nivelBateria=" + getNivelBateria() + ", prioridad=" 
                + getPrioridad() + '}';
    }
    
    
}
