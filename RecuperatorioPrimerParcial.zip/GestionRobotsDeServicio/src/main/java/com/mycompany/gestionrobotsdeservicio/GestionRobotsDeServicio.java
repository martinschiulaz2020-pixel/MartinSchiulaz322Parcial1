/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestionrobotsdeservicio;

/**
 *
 * @author PC
 */
public class GestionRobotsDeServicio {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
