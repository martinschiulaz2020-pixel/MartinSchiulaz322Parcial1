
package com.mycompany.gestionrobotsdeservicio;

import java.awt.BorderLayout;

public class RobotsReparto extends Robots implements EjecutarServicio, GenerarDiagnostico{

    private int capacidadCarga;
    public RobotsReparto(String numeroSerie, String fabricante, 
            PrioridadServicio prioridad, int nivelBateria, int capacidadCarga) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        validarCapacidadCarga(capacidadCarga);
    }
    
    private void validarCapacidadCarga(int capacidadCarga){
        if (capacidadCarga < 1){
            throw new IllegalArgumentException("la capacidad de carga no puede ser menor a uno");
        }
    }
    
    @Override
    int calcularConsumoEnergia() {
        return capacidadCarga * 3 + 4;
    }

    @Override
    public String servicio() {
    if (getNivelBateria() > calcularConsumoEnergia()){
        System.out.println("Se ejecuto el servicio");
        }
        throw new IllegalStateException();
    }

    @Override
    public String diagnostico() {
        return "Se realizo el diagnostico";   
    }
    
}
