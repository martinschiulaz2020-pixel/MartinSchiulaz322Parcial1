
package com.mycompany.gestionrobotsdeservicio;


public interface EjecutarServicio {
    
    
    String servicio();
}
