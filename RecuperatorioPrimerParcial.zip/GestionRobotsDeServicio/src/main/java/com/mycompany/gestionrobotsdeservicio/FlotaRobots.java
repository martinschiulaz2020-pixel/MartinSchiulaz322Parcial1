
package com.mycompany.gestionrobotsdeservicio;

import java.util.ArrayList;
import java.util.List;


public class FlotaRobots {
    
    private String nombre;
    private List<Robots> robots;

    public FlotaRobots(String nombre) {
        validarString(nombre);
        this.nombre = nombre;
        this.robots  = new ArrayList<>();
    }
    
    private void validarString(String string){
        if (string == null || string.isEmpty()){
            throw new IllegalArgumentException("No dejar espacios en blanco");
        }
    }
    
    public void agregarRobot(Robots robot) throws RobotDuplicadoException{
        validarRobotRepetido(robot);
        robots.add(robot);
    }
    
    private void validarRobotRepetido(Robots robot) throws RobotDuplicadoException {
        if(robot == null || robots.contains(robot)){
            throw new RobotDuplicadoException("Ese robot ya esta asignado");
        }
    }
    
    public List<Robots> obtenerRobots(List<Robots> robots){
        List copia = new ArrayList<>(robots);
        return copia;        
    }
    
    public List<Robots> obtenerRobotsConConsumoMaximo(int maximo){
        List<Robots> copia = new ArrayList<>(robots);
        for(Robots robot : copia){
            if(robot.calcularConsumoEnergia() == maximo){
                copia.add(robot);
            }  
        }
        return copia;
    }
    
    public List<Robots> filtrarPorPrioridad(PrioridadServicio prioridad){
        List<Robots> copia = new ArrayList<>(robots);
        for(Robots robot : copia){
            if(robot.getPrioridad() == prioridad){
                copia.add(robot);
            }  
        }
        return copia;
    }
    
     
}
