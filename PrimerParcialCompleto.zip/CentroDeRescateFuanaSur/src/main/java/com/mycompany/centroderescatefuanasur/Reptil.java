package com.mycompany.centroderescatefuanasur;

public class Reptil extends Animal implements Liberable{
    
    private int longitud;
    private static final int COSTO_DIARIO = 15;
    private static final int LONGITUD_MINIMA = 1;
    
    
    public Reptil(String codigo, String nombre, EstadoSalud estado, int longitud) {
        super(codigo, nombre, estado);
        
        this.longitud = longitud;
    }

    public int getLongitud() {
        return longitud;
    }
    
    private void validarLongitud(){
        if (longitud < LONGITUD_MINIMA){
            throw new IllegalArgumentException("La longitud no puede ser menor a 1");
        }
    }

    @Override
    int CalcularCostoDiario() {
        return longitud + COSTO_DIARIO;
    }

    @Override
    public String liberar() {
        return "El reptil" + getNombre() + "con codigo" + 
                getCodigo() + "a sido liberado";
    }

    @Override
    public String toString() {
        return "Reptil{" + "codigo= " + getCodigo() + ", nombre= " 
                + getNombre() + ", estado= " + getEstado() + 
                "longitud= " + longitud + '}';
    }
    
    
    
}
