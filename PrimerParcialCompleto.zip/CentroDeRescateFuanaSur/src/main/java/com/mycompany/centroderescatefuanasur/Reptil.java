package com.mycompany.centroderescatefuanasur;
/**
 * la clase que crea los reptiles extiende de Animal y implementa la interfaz
 * Liberable
 */
public class Reptil extends Animal implements Liberable{
    
    private int longitud;
    private static final int COSTO_DIARIO = 15;
    private static final int LONGITUD_MINIMA = 1;
    
    /**
    * esta clase es hija de animal y es donde se crean las aves, 
    * implementando Rehabilitable y Liberable
    * @param codigo usa el codigo identificatorio, heredado de Animal
    * @param nombre usa el nombre identificatorio, heredado de Animal
    * @param estado el estado de salud en que se encuentra el animal
    * @param longitud indica cuanta longitud, mayor a 1, puede
    * tener
    */
    public Reptil(String codigo, String nombre, EstadoSalud estado, int longitud) {
        super(codigo, nombre, estado);
        
        this.longitud = longitud;
    }

    public int getLongitud() {
        return longitud;
    }
    /**
     * valida que la longitud no sea menor a LONGITUD_MINIMA = 1
     */
    private void validarLongitud(){
        if (longitud < LONGITUD_MINIMA){
            throw new IllegalArgumentException("La longitud no puede ser menor a 1");
        }
    }

    @Override
    /**
     * calcula el coste diario de los reptiles longitud + COSTO_DIARIO = 15
     */
    int CalcularCostoDiario() {
        return longitud + COSTO_DIARIO;
    }

    @Override
    /**
     * indica que el animal sea liberable
     */
    public String liberar() {
        return "El reptil" + getNombre() + "con codigo" + 
                getCodigo() + "a sido liberado";
    }

    @Override
    /**
     * usa el toString del padre y agrega su longitud
     */
    public String toString() {
        return "Reptil{" + "codigo= " + getCodigo() + ", nombre= " 
                + getNombre() + ", estado= " + getEstado() + 
                "longitud= " + longitud + '}';
    }
    
    
    
}
