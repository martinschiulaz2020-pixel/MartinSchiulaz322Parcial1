
package com.mycompany.centroderescatefuanasur;


import java.util.ArrayList;
import java.util.List;

/**
 * Es la clase en donde se crea el centro para guardar 
 * y controlar a todos los animales del refugio
 * 
 */
public class CentroRescate {
    
    private String nombre;
    private List<Animal> animales;
    
    /**
     * es el constructor del refugio en donde se van a guardar los animales
     * @param nombre el nombre del centro de rescate
     */
    public CentroRescate(String nombre) {
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre no puede ser nulo ni estar vacio");
        }
        this.nombre = nombre;
        this.animales = new ArrayList<>();
    }
    /**
     * agrega animales al refugio y chequea que no sea repetido
     * @param animal el animal que necesitas agregar al refugio
     * @throws AnimalDuplicadoException si el animal ya existe con el mismo
     * codigo y nombre tira esta exception
     * @throws IllegalArgumentException si el animal es nulo tira esta otra exception
     */
    public void agregarAnimal(Animal animal) throws AnimalDuplicadoException{
        chequearAnimal(animal);
        animales.add(animal);
    }   
    /**
     * verifica que el animal no este dentro de la lista y que no sea nulo
     * @param animal el animal a ser chequeado
     * @throws AnimalDuplicadoException tira esta exeption si ya esta dentro 
     * de la lista con el mismo nombre y codigo
     * @throws IllegalArgumentException tira esta exeption si el animal es nulo
     */
    private void chequearAnimal(Animal animal) throws AnimalDuplicadoException {
        if (animal == null){
            throw new IllegalArgumentException("No se puede agregar un animal nulo");
        }
        if (animales.contains(animal)){
            throw new AnimalDuplicadoException("El animal" + animal.getNombre() +
                    "con codigo" + animal.getCodigo() + "ya esta registrado");
        }       
    }
    /**
     * crea una copia de todos los animales que esten en el refugio
     * @return retorna la copia de los animales que estan en el refugio
     */
    public List<Animal> obtenerAnimales(){
        List<Animal> copia = new ArrayList<>(animales);
        return copia;
    }
    /**
     * filtra los animales por el estado indicado y los guarda en una lista
     * @param estado el estado de salud en que se encuentra el animal 
     * @return retorna la lista con los animales ya filtrados
     */
    public List<Animal> filtrarPorEstado(EstadoSalud estado){
        if(estado == null){
            throw new IllegalArgumentException("Estado no puede ser nulo");
        }
        List<Animal> filtrados = new ArrayList<>();
        for (Animal animal : animales){
            if (animal.getEstado() == estado){
                filtrados.add(animal);
            }
        }
        return filtrados;
    }
    /**
     * busca entre la lista de animales cual es el de mayor costo
     * @param maximo le pasas el maximo que queres que tenga el animal
     * @return retorna una copia de los animales con el maximo costo 
     */
    public List<Animal> obtenerAnimalesConCostoMaximo(int maximo){
        if(maximo < 1){
            throw new IllegalArgumentException("el costo maximo no puede ser menor a 1");
        }
        List<Animal> filtrados = new ArrayList<>();
        for(Animal animal : animales){
            if ( animal.CalcularCostoDiario() <= maximo){
                filtrados.add(animal);
            }
        }
        return filtrados;   
    }
    
        
}
