
package com.mycompany.centroderescatefuanasur;


import java.util.ArrayList;
import java.util.List;


public class CentroRescate {
    
    private String nombre;
    private List<Animal> animales;

    public CentroRescate(String nombre) {
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre no puede ser nulo ni estar vacio");
        }
        this.nombre = nombre;
        this.animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal animal) throws AnimalDuplicadoException{
        chequearAnimal(animal);
        animales.add(animal);
    }   
 
    private void chequearAnimal(Animal animal) throws AnimalDuplicadoException {
        if (animal == null){
            throw new IllegalArgumentException("No se puede agregar un animal nulo");
        }
        if (animales.contains(animal)){
            throw new AnimalDuplicadoException("El animal" + animal.getNombre() +
                    "con codigo" + animal.getCodigo() + "ya esta registrado");
        }       
    }
    
    public List<Animal> obtenerAnimales(){
        List<Animal> copia = new ArrayList<>(animales);
        return copia;
    }
    
    public List<Animal> filtrarPorEstado(EstadoSalud estado){
        if(estado == null){
            throw new IllegalArgumentException("Estado no puede ser nulo");
        }
        List<Animal> filtrados = new ArrayList<>();
        for (Animal animal : animales){
            if (animal.getEstado() == estado){
                filtrados.add(animal);
            }
        }
        return filtrados;
    }
    
    public List<Animal> obtenerAnimalesConCostoMaximo(int maximo){
        if(maximo < 1){
            throw new IllegalArgumentException("el costo maximo no puede ser menor a 1");
        }
        List<Animal> filtrados = new ArrayList<>();
        for(Animal animal : animales){
            if ( animal.CalcularCostoDiario() <= maximo){
                filtrados.add(animal);
            }
        }
        return filtrados;   
    }
    
        
}
