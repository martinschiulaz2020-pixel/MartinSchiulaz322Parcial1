package com.mycompany.centroderescatefuanasur;



public class Mamifero extends Animal implements Rehabilitable{
    
    private final int peso;
    private static final int PESO_MINIMO = 1;
    private static final int COSTO_DIARIO = 10;
    
    public Mamifero(String codigo, String nombre, EstadoSalud estado, int peso) {
        super(codigo, nombre, estado);
        validarPeso(peso);
        this.peso = peso;
    }
    
    private void validarPeso(int peso){
        if(peso < PESO_MINIMO){
            throw new IllegalArgumentException("El peso no puede ser negativo");
        }
    }
    
    
    @Override
    int CalcularCostoDiario() {
        return peso * COSTO_DIARIO;
    }

    public int getPeso() {
        return peso;
    }

    @Override
    public String toString() {
        return "Animal{" + "codigo= " + getCodigo() + 
                ", nombre= " + getNombre() + 
                ", estado= " + getEstado() + 
                ", peso= " + peso + '}';
    }

    @Override
    public String rehabilitar() {
         return "El mamifero " + getNombre()
            + " con codigo " + getCodigo()
            + " esta recibiendo rehabilitacion.";
    }
    
    
    
    
    
    
}
