package com.mycompany.centroderescatefuanasur;


/**
 * esta clase es hija de animal y es donde se crean los mamiferos, implementando
 * la interfaz Rehabilitable
 * 
 */
public class Mamifero extends Animal implements Rehabilitable{
    
    private final int peso;
    private static final int PESO_MINIMO = 1;
    private static final int COSTO_DIARIO = 10;
    /**
     * es el constructor de los mamiferos
     * @param codigo usa el codigo identificatorio, heredado de Animal
     * @param nombre usa el nombre identificatorio, heredado de Animal
     * @param estado el estado de salud en que se encuentra el animal
     * @param peso indica cuanto peso, mayor a 1, puede tener el mamifero
     */
    public Mamifero(String codigo, String nombre, EstadoSalud estado, int peso) {
        super(codigo, nombre, estado);
        validarPeso(peso);
        this.peso = peso;
    }
    /**
     * valida que el peso no sea menor al PESO_MINIMO = 1
     * @param peso parametro utilizado para validar el peso
     */
    private void validarPeso(int peso){
        if(peso < PESO_MINIMO){
            throw new IllegalArgumentException("El peso no puede ser negativo");
        }
    }
    
    
    @Override
    /**
     * calcula el coste diario del animal mamifero, 
     * es su peso * COSTO_DIARIO = 10
     */
    int CalcularCostoDiario(){
        return peso * COSTO_DIARIO;
    }

    public int getPeso() {
        return peso;
    }

    @Override
    /**
     * usa el toString de la clase Animal y agrega su peso 
     */
    public String toString() {
        return "Animal{" + "codigo= " + getCodigo() + 
                ", nombre= " + getNombre() + 
                ", estado= " + getEstado() + 
                ", peso= " + peso + '}';
    }

    @Override
    /**
     * indica que el animal esta recibiendo rehabilitacion
     */
    public String rehabilitar() {
         return "El mamifero " + getNombre()
            + " con codigo " + getCodigo()
            + " esta recibiendo rehabilitacion.";
    }
    
    
    
    
    
    
}
