package com.mycompany.centroderescatefuanasur;
/**
 * la clase que crea las aves y hereda de Animal con la implementacion de 
 * rehabilitable y liberable
 */
public class Ave extends Animal implements Rehabilitable, Liberable{
    
   private int envergaduraAlar;
   private static final int COSTO_DIARIO = 2;
   private static final int ENVERGADURA_ALAR_MINIMA = 1;
    /**
     * esta clase es hija de animal y es donde se crean las aves, 
     * implementando Rehabilitable y Liberable
     * @param codigo usa el codigo identificatorio, heredado de Animal
     * @param nombre usa el nombre identificatorio, heredado de Animal
     * @param estado el estado de salud en que se encuentra el animal
     * @param envergaduraAlar indica cuanta envergadura alar, mayor a 1, puede
     * tener
     */
    public Ave(String codigo, String nombre, EstadoSalud estado, int envergaduraAlar) {
        super(codigo, nombre, estado);
        validarEnvergaduraAlar(envergaduraAlar);
        this.envergaduraAlar = envergaduraAlar;     
    }

    public int getEnvergaduraAlar() {
        return envergaduraAlar;
    }

    @Override
    /**
     * usa el toString de la clase Animal y agrega su envergadura alar
     */
    public String toString() {
        return "Animal{" + "codigo= " + getCodigo() + 
                ", nombre= " + getNombre() + 
                ", estado= " + getEstado() + 
                ", envergadura alar= " + envergaduraAlar +   '}';
    }
    
    @Override
    /**
    * calcula el costo diario de las aves, es su envergadura * COSTO_DIARIO = 2
    */
    int CalcularCostoDiario() {
        return envergaduraAlar * COSTO_DIARIO;
    }
    /**
     * valida que la envergadura alar sea mayor a la 
     * ENVERGADURA_ALAR_MINIMA = 1
     * @param envergaduraAlar 
     */
    private void validarEnvergaduraAlar(int envergaduraAlar){
        if(envergaduraAlar < ENVERGADURA_ALAR_MINIMA){
            throw new IllegalArgumentException("La envergadura alar no puede ser negativa");
        }
    }
    
    @Override
    /**
     * indica que el animal se puede rehabilitar
     */
    public String rehabilitar() {
        return "El ave " + getNombre()
            + " con codigo " + getCodigo()
            + " esta recibiendo rehabilitacion.";
    }

    @Override
    /**
     * indica que el animal se puede liberar
     */
    public String liberar() {
        return "El ave" + getNombre() + "con codigo" + 
                getCodigo() + "a sido liberada";
    }

    
   
    
    
}
