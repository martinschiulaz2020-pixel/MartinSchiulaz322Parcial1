package com.mycompany.centroderescatefuanasur;

public class Ave extends Animal implements Rehabilitable, Liberable{
    
   private int envergaduraAlar;
   private static final int COSTO_DIARIO = 2;
   private static final int ENVERGADURA_ALAR_MINIMA = 1;

    public Ave(String codigo, String nombre, EstadoSalud estado, int envergaduraAlar) {
        super(codigo, nombre, estado);
        validarEnvergaduraAlar(envergaduraAlar);
        this.envergaduraAlar = envergaduraAlar;     
    }

    public int getEnvergaduraAlar() {
        return envergaduraAlar;
    }

    @Override
    public String toString() {
        return "Animal{" + "codigo= " + getCodigo() + 
                ", nombre= " + getNombre() + 
                ", estado= " + getEstado() + 
                ", envergadura alar= " + envergaduraAlar +   '}';
    }
    
    @Override
    int CalcularCostoDiario() {
        return envergaduraAlar * COSTO_DIARIO;
    }
    
    private void validarEnvergaduraAlar(int envergaduraAlar){
        if(envergaduraAlar < ENVERGADURA_ALAR_MINIMA){
            throw new IllegalArgumentException("La envergadura alar no puede ser negativa");
        }
    }
    
    @Override
    public String rehabilitar() {
        return "El ave " + getNombre()
            + " con codigo " + getCodigo()
            + " esta recibiendo rehabilitacion.";
    }

    @Override
    public String liberar() {
        return "El ave" + getNombre() + "con codigo" + 
                getCodigo() + "a sido liberada";
    }

    
   
    
    
}
