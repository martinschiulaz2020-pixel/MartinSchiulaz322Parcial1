package com.mycompany.centroderescatefuanasur;

/**
 * sirve para indicar si el animal se puede liberar
 */
public interface Liberable {
    /**
     * metedo a implementar por las clases que sean liberables
     * @return un mensaje que indica si se puede liberar
     */
    String liberar();
    
    
    
}
