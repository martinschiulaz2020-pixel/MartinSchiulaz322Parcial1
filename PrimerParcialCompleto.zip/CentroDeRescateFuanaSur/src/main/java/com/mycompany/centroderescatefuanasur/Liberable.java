package com.mycompany.centroderescatefuanasur;


public interface Liberable {
    
    String liberar();
    
    
    
}
