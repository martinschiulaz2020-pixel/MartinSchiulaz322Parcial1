
package com.mycompany.centroderescatefuanasur;

import java.util.Objects;
/**
 * es la clase que se encarga de definir los parametros 
 * que van a tener los animales, junto con metodos y atributos heredados
 * 
 */
public abstract class Animal{
    
    private final String codigo;
    private final String nombre;
    private EstadoSalud estado;
    /**
     * es el constructor que utilizan las clases hijas para crear los animales
     * @param codigo es uno de los sellos identificatorios del animal
     * @param nombre es uno de los sellos identificatorios del animal
     * @param estado el estado de salud en que se encuentra el animal
     * @throws IllegalArgumentException si el los campos estan vacios 
     * o en blanco arroja esta exception
     */
    protected Animal(String codigo, String nombre, EstadoSalud estado) {
        validarNullYVacio(codigo, "codigo");
        validarNullYVacio(nombre, "nombre");
        validarEstadoSalud(estado);
        this.codigo = codigo;
        this.nombre = nombre;
        this.estado = estado;
    }
    /**
     * valida que los animales creados no sean null, ni esten vacios
     * @param validar el parametro String a validar
     * @param campo el campo es o el codigo o el nombre segun sea indicado
     */
    private void validarNullYVacio(String validar, String campo){
        if (validar == null || validar.isBlank()){
            throw new IllegalArgumentException("El"+ campo + "no puede estar vacio");
        }
    }
    /**
     * valida que el estado no sea null
     * @param estado estado en que se encuentra el animal
     */
    private void validarEstadoSalud(EstadoSalud estado){
        if(estado == null){
            throw new IllegalArgumentException("El estadi de salud no puede estar vacio");
        }
    }

    String getCodigo() {
        return codigo;
    }

    String getNombre() {
        return nombre;
    }

    EstadoSalud getEstado() {
        return estado;
    }
    /**
     * define como se calcula el costo diario de cada animal, sera aplicado por
     * cada animal segun corresponda
     * @return el costo diario
     */
    abstract int CalcularCostoDiario(); 
     
    
    @Override
    /**
     * lo que se muestra del animal al ser utilizado en un System.out.println().
     * hay agregados segun el tipo de animal
     */
    public String toString() {
        return "Animal{" + "codigo= " + codigo + ", nombre= " + nombre + ", estado= " + estado + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.codigo);
        hash = 29 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    /**
     * compara si dos animales tienen el mismo nombre o 
     * codigo para ver si son iguales
     * 
     */
    public boolean equals(Object obj) {
        boolean iguales = false;
        if (this == obj) {
            iguales = true;
        }else if(obj instanceof Animal){
            Animal otro = (Animal) obj;
            
            iguales = Objects.equals(this.codigo, otro.codigo)
            && Objects.equals(this.nombre, otro.nombre);   
        }
        {   
        }
        return iguales;
    }
    
    }

    
    
    
    
    
    
    
    

        



    
    
    
