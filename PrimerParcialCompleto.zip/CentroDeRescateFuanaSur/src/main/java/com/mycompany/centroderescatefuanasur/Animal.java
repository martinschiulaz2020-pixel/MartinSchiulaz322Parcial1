
package com.mycompany.centroderescatefuanasur;

import java.util.Objects;

public abstract class Animal{
    
    private final String codigo;
    private final String nombre;
    private EstadoSalud estado;

    protected Animal(String codigo, String nombre, EstadoSalud estado) {
        validarNullYVacio(codigo, "codigo");
        validarNullYVacio(nombre, "nombre");
        validarEstadoSalud(estado);
        this.codigo = codigo;
        this.nombre = nombre;
        this.estado = estado;
    }
    
    private void validarNullYVacio(String validar, String campo){
        if (validar == null || validar.isBlank()){
            throw new IllegalArgumentException("El"+ campo + "no puede estar vacio");
        }
    }
    
    private void validarEstadoSalud(EstadoSalud estado){
        if(estado == null){
            throw new IllegalArgumentException("El estadi de salud no puede estar vacio");
        }
    }

    String getCodigo() {
        return codigo;
    }

    String getNombre() {
        return nombre;
    }

    EstadoSalud getEstado() {
        return estado;
    }
    
    abstract int CalcularCostoDiario(); 
     

    @Override
    public String toString() {
        return "Animal{" + "codigo= " + codigo + ", nombre= " + nombre + ", estado= " + estado + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.codigo);
        hash = 29 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        boolean iguales = false;
        if (this == obj) {
            iguales = true;
        }else if(obj instanceof Animal){
            Animal otro = (Animal) obj;
            
            iguales = Objects.equals(this.codigo, otro.codigo)
            && Objects.equals(this.nombre, otro.nombre);   
        }
        {   
        }
        return iguales;
    }
    
    }

    
    
    
    
    
    
    
    

        



    
    
    
