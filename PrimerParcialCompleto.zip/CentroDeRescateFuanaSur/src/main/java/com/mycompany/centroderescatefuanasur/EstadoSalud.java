
package com.mycompany.centroderescatefuanasur;
/**
 * son los estados clasificados del refugio en que se puede encontrar un animal
 */
public enum EstadoSalud {
    CRITICO,
    EN_RECUPERACION,
    ESTABLE;         
}
