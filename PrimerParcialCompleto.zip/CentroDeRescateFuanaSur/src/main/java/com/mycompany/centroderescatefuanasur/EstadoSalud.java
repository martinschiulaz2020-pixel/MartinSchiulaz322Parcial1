
package com.mycompany.centroderescatefuanasur;

public enum EstadoSalud {
    CRITICO,
    EN_RECUPERACION,
    ESTABLE;         
}
