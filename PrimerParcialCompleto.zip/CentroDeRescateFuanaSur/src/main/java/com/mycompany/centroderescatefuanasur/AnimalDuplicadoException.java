
package com.mycompany.centroderescatefuanasur;

public class AnimalDuplicadoException extends Exception {
    
    public final static String MENSAJE = "Animal duplicado";
    
    public AnimalDuplicadoException() {
        this(MENSAJE);
    }

    public AnimalDuplicadoException(String mensaje) {
        super(mensaje);
    }
    
    
    
}
