
package com.mycompany.centroderescatefuanasur;
/**
 * Exception chequeada en la cual se utiliza para cuando alla un animal
 * repetido en el refugio
 */
public class AnimalDuplicadoException extends Exception {
    
    public final static String MENSAJE = "Animal duplicado";
    /**
     * exception con mensaje predeterminado
     */
    public AnimalDuplicadoException() {
        this(MENSAJE);
    }
    /**
     * exception con mensaje predeterminado y posibilidad de agregar el mensaje
     * que se desea
     * @param mensaje aca se puede escribir el mensaje deseado 
     */
    public AnimalDuplicadoException(String mensaje) {
        super(mensaje);
    }
    
    
    
}
