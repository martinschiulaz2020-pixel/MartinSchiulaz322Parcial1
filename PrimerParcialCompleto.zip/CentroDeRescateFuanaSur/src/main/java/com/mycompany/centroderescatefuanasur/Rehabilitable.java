package com.mycompany.centroderescatefuanasur;

/**
 * sirve para indicar si el animal se puede rehabilitar o 
 * si esta en rehabilitacion
 */
public interface Rehabilitable {
    /**
     * metedo a implementar por las clases que sean rehabilitables
     * @return un mensaje que indica si se esta rehabilitando
     */
    String rehabilitar();
    
        
}
