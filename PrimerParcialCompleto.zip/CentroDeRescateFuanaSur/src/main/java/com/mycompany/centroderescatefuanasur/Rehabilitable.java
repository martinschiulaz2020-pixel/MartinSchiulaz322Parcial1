package com.mycompany.centroderescatefuanasur;


public interface Rehabilitable {
    
    String rehabilitar();
    
        
}
